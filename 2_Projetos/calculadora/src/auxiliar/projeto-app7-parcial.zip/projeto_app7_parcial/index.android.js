import React from 'react';
import { AppRegistry } from 'react-native';

import App from './src/App';

const app7 = () => (
  <App />
);

AppRegistry.registerComponent('app7', () => app7);
