import React from 'react';
import { View, Text } from 'react-native';

import Cabecalho from './Cabecalho'

const Topo = props => (
	<Cabecalho />
);

export { Topo };
